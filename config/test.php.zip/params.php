<?php

return [
    'adminEmail' => 'talentbookservices@gmail.com',
];
